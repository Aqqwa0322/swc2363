<?php
// Database connection details
$servername = "localhost"; // Usually "localhost"
$username = "root"; // Default username for phpMyAdmin
$password = ""; // Default password for phpMyAdmin, empty for default
$dbname = "sales_db"; // Your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted and all fields are set
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id'], $_POST['name'], $_POST['month'], $_POST['sales'])) {

    // Get the input values and sanitize
    $employee_id = htmlspecialchars($_POST['id']);
    $name = htmlspecialchars($_POST['name']);
    $month = htmlspecialchars($_POST['month']);
    $sales = (float) $_POST['sales'];

    // Calculate the commission based on sales amount
    if ($sales >= 1 && $sales <= 2000) {
        $commission = $sales * 0.05;
    } elseif ($sales >= 2001 && $sales <= 5000) {
        $commission = $sales * 0.06;
    } elseif ($sales >= 5001 && $sales <= 7000) {
        $commission = $sales * 0.08;
    } elseif ($sales > 7000) {
        $commission = $sales * 0.15;
    } else {
        $commission = 0;
    }

    // Prepare and bind the SQL statement to insert data into the database
    $stmt = $conn->prepare("INSERT INTO sales_commission (employee_id, name, month, sales_amount, commission) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssdd", $employee_id, $name, $month, $sales, $commission);

    // Execute the query
    if ($stmt->execute()) {
        // If the insertion is successful, display the results
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Sales Commission</title>
            <link rel="stylesheet" href="style.css">
        </head>
        <body>
            <div class="container">
                <!-- Success message -->
                <div class="success">
                    Record successfully inserted.
                </div>
                <!-- Display calculated results -->
                <h2>Sales Commission</h2>
                <p><strong>ID:</strong> <?php echo $employee_id; ?></p>
                <p><strong>Name:</strong> <?php echo $name; ?></p>
                <p><strong>Month:</strong> <?php echo $month; ?></p>
                <p><strong>Sales Amount:</strong> RM <?php echo number_format($sales, 2); ?></p>
                <p><strong>Commission:</strong> RM <?php echo number_format($commission, 2); ?></p>
            </div>
        </body>
        </html>
        <?php
    } else {
        // If there's an error inserting data into the database
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();

} else {
    // Error message if form data is missing
    echo "Form data is missing. Please submit the form correctly.";
}
?>
